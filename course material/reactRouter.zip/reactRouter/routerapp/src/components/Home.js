import React from 'react'
import { Outlet } from 'react-router-dom'

const Home = () => {
  return (
    <div>
    
        This is my HomePage
      
    </div>
  )
}

export default Home
