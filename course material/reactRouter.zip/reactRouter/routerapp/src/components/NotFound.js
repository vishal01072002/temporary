import React from 'react'

const NotFound = () => {
  return (
    <div>
      This is NOT FOund Page
    </div>
  )
}

export default NotFound
