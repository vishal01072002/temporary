import React from 'react'

const Home = ({isLoggedIn}) => {
  return (
    <div className='flex justify-center items-center text-white text-3xl h-full'>
      Home
    </div>
  )
}

export default Home
