function Home() {
  return (
    <div className="flex flex-1 justify-center items-center text-white text-3xl">
      Home
    </div>
  );
}

export default Home;
