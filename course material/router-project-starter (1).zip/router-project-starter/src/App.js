import "./App.css";

function App() {
  return <div>Hello World</div>;
}

export default App;
